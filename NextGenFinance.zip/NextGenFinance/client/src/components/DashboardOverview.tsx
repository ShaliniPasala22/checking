import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { TrendingUp, TrendingDown, DollarSign, Target, CreditCard, PiggyBank } from "lucide-react";

interface DashboardOverviewProps {
  totalBalance: number;
  monthlyIncome: number;
  monthlyExpenses: number;
  savingsGoal: number;
  currentSavings: number;
  budgetData: Array<{
    category: string;
    spent: number;
    limit: number;
  }>;
}

export default function DashboardOverview({
  totalBalance,
  monthlyIncome,
  monthlyExpenses,
  savingsGoal,
  currentSavings,
  budgetData
}: DashboardOverviewProps) {
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  const netIncome = monthlyIncome - monthlyExpenses;
  const savingsProgress = (currentSavings / savingsGoal) * 100;

  const getSpendingColor = (spent: number, limit: number) => {
    const percentage = (spent / limit) * 100;
    if (percentage >= 90) return 'text-banking-expense';
    if (percentage >= 75) return 'text-banking-warning';
    return 'text-banking-success';
  };

  return (
    <div className="space-y-6" data-testid="dashboard-overview">
      {/* Financial Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="hover-elevate" data-testid="card-total-balance">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Balance</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold" data-testid="text-total-balance">
              {formatCurrency(totalBalance)}
            </div>
            <p className="text-xs text-muted-foreground">
              Across all accounts
            </p>
          </CardContent>
        </Card>

        <Card className="hover-elevate" data-testid="card-monthly-income">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Monthly Income</CardTitle>
            <TrendingUp className="h-4 w-4 text-banking-success" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-banking-success" data-testid="text-monthly-income">
              {formatCurrency(monthlyIncome)}
            </div>
            <p className="text-xs text-muted-foreground">
              This month
            </p>
          </CardContent>
        </Card>

        <Card className="hover-elevate" data-testid="card-monthly-expenses">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Monthly Expenses</CardTitle>
            <TrendingDown className="h-4 w-4 text-banking-expense" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-banking-expense" data-testid="text-monthly-expenses">
              {formatCurrency(monthlyExpenses)}
            </div>
            <p className="text-xs text-muted-foreground">
              Net: <span className={netIncome >= 0 ? 'text-banking-success' : 'text-banking-expense'}>
                {formatCurrency(netIncome)}
              </span>
            </p>
          </CardContent>
        </Card>

        <Card className="hover-elevate" data-testid="card-savings-goal">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Savings Goal</CardTitle>
            <Target className="h-4 w-4 text-banking-trust" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold" data-testid="text-savings-progress">
              {savingsProgress.toFixed(0)}%
            </div>
            <Progress value={savingsProgress} className="mt-2" />
            <p className="text-xs text-muted-foreground mt-1">
              {formatCurrency(currentSavings)} of {formatCurrency(savingsGoal)}
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Budget Overview */}
      <Card data-testid="card-budget-overview">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <PiggyBank className="h-5 w-5 text-banking-trust" />
            Budget Overview
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {budgetData.map((budget, index) => {
            const percentage = (budget.spent / budget.limit) * 100;
            const colorClass = getSpendingColor(budget.spent, budget.limit);
            
            return (
              <div key={index} className="space-y-2" data-testid={`budget-item-${budget.category.toLowerCase().replace(/\s+/g, '-')}`}>
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-2">
                    <span className="font-medium text-sm">{budget.category}</span>
                    <Badge 
                      variant={percentage >= 90 ? "destructive" : percentage >= 75 ? "secondary" : "default"}
                      className="text-xs"
                    >
                      {percentage.toFixed(0)}%
                    </Badge>
                  </div>
                  <div className="text-right">
                    <span className={`font-semibold ${colorClass}`}>
                      {formatCurrency(budget.spent)}
                    </span>
                    <span className="text-muted-foreground text-sm">
                      /{formatCurrency(budget.limit)}
                    </span>
                  </div>
                </div>
                <Progress 
                  value={percentage} 
                  className={`h-2 ${percentage >= 90 ? 'bg-banking-expense/20' : ''}`}
                />
              </div>
            );
          })}
        </CardContent>
      </Card>
    </div>
  );
}