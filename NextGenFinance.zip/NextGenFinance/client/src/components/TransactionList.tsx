import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ArrowUpRight, ArrowDownLeft, Coffee, ShoppingBag, Car, Home, Utensils, MoreHorizontal } from "lucide-react";

interface Transaction {
  id: string;
  amount: number;
  description: string;
  category: string;
  type: 'credit' | 'debit';
  date: string;
  merchant?: string;
}

interface TransactionListProps {
  transactions: Transaction[];
  title?: string;
}

const categoryIcons: Record<string, any> = {
  "Food & Dining": Utensils,
  "Shopping": ShoppingBag,
  "Transportation": Car,
  "Housing": Home,
  "Coffee": Coffee,
  "Income": ArrowDownLeft,
  "Other": MoreHorizontal,
};

export default function TransactionList({ transactions, title = "Recent Transactions" }: TransactionListProps) {
  const formatAmount = (amount: number, type: 'credit' | 'debit') => {
    const formatted = new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(Math.abs(amount));
    
    return type === 'credit' ? `+${formatted}` : `-${formatted}`;
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric'
    });
  };

  const getCategoryIcon = (category: string) => {
    const Icon = categoryIcons[category] || categoryIcons["Other"];
    return <Icon className="h-4 w-4" />;
  };

  return (
    <Card data-testid="card-transaction-list">
      <CardHeader>
        <CardTitle className="flex items-center justify-between" data-testid="text-transaction-title">
          {title}
          <Button variant="ghost" size="sm" data-testid="button-view-all-transactions">
            View All
          </Button>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-2">
        {transactions.map((transaction) => {
          const Icon = transaction.type === 'credit' ? ArrowDownLeft : ArrowUpRight;
          
          return (
            <div
              key={transaction.id}
              className="flex items-center justify-between p-3 rounded-lg hover-elevate border border-border"
              data-testid={`row-transaction-${transaction.id}`}
            >
              <div className="flex items-center gap-3">
                <div className={`p-2 rounded-full ${
                  transaction.type === 'credit' 
                    ? 'bg-banking-income/10 text-banking-income' 
                    : 'bg-banking-expense/10 text-banking-expense'
                }`}>
                  {getCategoryIcon(transaction.category)}
                </div>
                <div className="space-y-1">
                  <p className="font-medium text-sm" data-testid={`text-transaction-description-${transaction.id}`}>
                    {transaction.description}
                  </p>
                  <div className="flex items-center gap-2">
                    <Badge variant="secondary" className="text-xs" data-testid={`badge-category-${transaction.id}`}>
                      {transaction.category}
                    </Badge>
                    {transaction.merchant && (
                      <span className="text-xs text-muted-foreground" data-testid={`text-merchant-${transaction.id}`}>
                        {transaction.merchant}
                      </span>
                    )}
                  </div>
                </div>
              </div>
              <div className="text-right space-y-1">
                <p className={`font-semibold ${
                  transaction.type === 'credit' 
                    ? 'text-banking-income' 
                    : 'text-banking-expense'
                }`} data-testid={`text-amount-${transaction.id}`}>
                  {formatAmount(transaction.amount, transaction.type)}
                </p>
                <p className="text-xs text-muted-foreground" data-testid={`text-date-${transaction.id}`}>
                  {formatDate(transaction.date)}
                </p>
              </div>
            </div>
          );
        })}
        {transactions.length === 0 && (
          <div className="text-center py-8 text-muted-foreground" data-testid="text-no-transactions">
            No transactions found
          </div>
        )}
      </CardContent>
    </Card>
  );
}