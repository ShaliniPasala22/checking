import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowUpDown, CreditCard, PiggyBank, Receipt, Send, Smartphone, QrCode, Bell } from "lucide-react";

interface QuickActionsProps {
  onActionClick?: (action: string) => void;
}

export default function QuickActions({ onActionClick }: QuickActionsProps) {
  const actions = [
    {
      id: 'transfer',
      label: 'Transfer Money',
      icon: ArrowUpDown,
      description: 'Between accounts',
      color: 'text-banking-trust'
    },
    {
      id: 'pay-bills',
      label: 'Pay Bills',
      icon: Receipt,
      description: 'Quick payments',
      color: 'text-banking-warning'
    },
    {
      id: 'send-money',
      label: 'Send Money',
      icon: Send,
      description: 'To friends & family',
      color: 'text-banking-success'
    },
    {
      id: 'mobile-deposit',
      label: 'Mobile Deposit',
      icon: Smartphone,
      description: 'Check deposit',
      color: 'text-banking-trust'
    },
    {
      id: 'qr-pay',
      label: 'QR Pay',
      icon: QrCode,
      description: 'Scan to pay',
      color: 'text-banking-neutral'
    },
    {
      id: 'card-controls',
      label: 'Card Controls',
      icon: CreditCard,
      description: 'Manage cards',
      color: 'text-banking-expense'
    },
    {
      id: 'savings-goals',
      label: 'Savings Goals',
      icon: PiggyBank,
      description: 'Track progress',
      color: 'text-banking-success'
    },
    {
      id: 'alerts',
      label: 'Alerts & Notifications',
      icon: Bell,
      description: 'Manage settings',
      color: 'text-banking-warning'
    }
  ];

  const handleActionClick = (actionId: string) => {
    console.log(`Quick action clicked: ${actionId}`); // TODO: remove mock functionality
    onActionClick?.(actionId);
  };

  return (
    <Card data-testid="card-quick-actions">
      <CardHeader>
        <CardTitle>Quick Actions</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {actions.map((action) => {
            const Icon = action.icon;
            
            return (
              <Button
                key={action.id}
                variant="ghost"
                className="h-auto flex-col gap-2 p-4 hover-elevate"
                onClick={() => handleActionClick(action.id)}
                data-testid={`button-action-${action.id}`}
              >
                <div className={`p-3 rounded-full bg-muted ${action.color}`}>
                  <Icon className="h-5 w-5" />
                </div>
                <div className="text-center space-y-1">
                  <p className="font-medium text-sm">{action.label}</p>
                  <p className="text-xs text-muted-foreground">{action.description}</p>
                </div>
              </Button>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}