import DashboardOverview from '../DashboardOverview';

export default function DashboardOverviewExample() {
  // TODO: remove mock functionality
  const mockData = {
    totalBalance: 15290.50,
    monthlyIncome: 4200.00,
    monthlyExpenses: 3147.32,
    savingsGoal: 10000.00,
    currentSavings: 6750.00,
    budgetData: [
      { category: 'Food & Dining', spent: 487.23, limit: 600 },
      { category: 'Transportation', spent: 234.56, limit: 300 },
      { category: 'Shopping', spent: 892.10, limit: 800 },
      { category: 'Entertainment', spent: 156.78, limit: 200 },
      { category: 'Utilities', spent: 287.45, limit: 350 }
    ]
  };

  return (
    <div className="max-w-6xl">
      <DashboardOverview {...mockData} />
    </div>
  );
}