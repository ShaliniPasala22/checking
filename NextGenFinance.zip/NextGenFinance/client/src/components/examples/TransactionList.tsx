import TransactionList from '../TransactionList';

export default function TransactionListExample() {
  // TODO: remove mock functionality
  const mockTransactions = [
    {
      id: '1',
      amount: 4.50,
      description: 'Morning Coffee',
      category: 'Food & Dining',
      type: 'debit' as const,
      date: '2024-01-15',
      merchant: 'Starbucks'
    },
    {
      id: '2',
      amount: 2500.00,
      description: 'Salary Deposit',
      category: 'Income',
      type: 'credit' as const,
      date: '2024-01-15'
    },
    {
      id: '3',
      amount: 89.99,
      description: 'Online Shopping',
      category: 'Shopping',
      type: 'debit' as const,
      date: '2024-01-14',
      merchant: 'Amazon'
    },
    {
      id: '4',
      amount: 25.00,
      description: 'Gas Station',
      category: 'Transportation',
      type: 'debit' as const,
      date: '2024-01-13',
      merchant: 'Shell'
    },
    {
      id: '5',
      amount: 1200.00,
      description: 'Rent Payment',
      category: 'Housing',
      type: 'debit' as const,
      date: '2024-01-12'
    }
  ];

  return (
    <div className="max-w-2xl">
      <TransactionList transactions={mockTransactions} />
    </div>
  );
}