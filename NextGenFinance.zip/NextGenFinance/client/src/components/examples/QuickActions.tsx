import QuickActions from '../QuickActions';

export default function QuickActionsExample() {
  const handleActionClick = (action: string) => {
    console.log(`Action clicked: ${action}`); // TODO: remove mock functionality
  };

  return (
    <div className="max-w-4xl">
      <QuickActions onActionClick={handleActionClick} />
    </div>
  );
}