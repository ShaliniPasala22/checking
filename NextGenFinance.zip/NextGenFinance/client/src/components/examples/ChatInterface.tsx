import ChatInterface from '../ChatInterface';
import { useState } from 'react';
import { Button } from '@/components/ui/button';

export default function ChatInterfaceExample() {
  const [isOpen, setIsOpen] = useState(true);

  return (
    <div className="relative h-96">
      <Button onClick={() => setIsOpen(true)} className="mb-4">
        Open Chat
      </Button>
      <ChatInterface isOpen={isOpen} onClose={() => setIsOpen(false)} />
    </div>
  );
}