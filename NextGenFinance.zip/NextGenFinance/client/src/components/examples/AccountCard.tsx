import AccountCard from '../AccountCard';

export default function AccountCardExample() {
  return (
    <div className="space-y-4 max-w-sm">
      <AccountCard
        accountName="Primary Checking"
        accountType="Checking"
        balance={2840.50}
        accountNumber="1234567890"
        gradient="from-blue-600 to-blue-800"
      />
      <AccountCard
        accountName="Emergency Savings"
        accountType="Savings"
        balance={12450.00}
        accountNumber="0987654321"
        gradient="from-green-600 to-green-800"
      />
      <AccountCard
        accountName="Platinum Card"
        accountType="Credit"
        balance={-892.33}
        accountNumber="5555444433332222"
        gradient="from-purple-600 to-purple-800"
      />
    </div>
  );
}