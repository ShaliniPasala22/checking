import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Eye, EyeOff, MoreHorizontal } from "lucide-react";
import { useState } from "react";

interface AccountCardProps {
  accountName: string;
  accountType: string;
  balance: number;
  accountNumber: string;
  gradient?: string;
}

export default function AccountCard({ 
  accountName, 
  accountType, 
  balance, 
  accountNumber,
  gradient = "from-blue-600 to-blue-800"
}: AccountCardProps) {
  const [showBalance, setShowBalance] = useState(true);

  const formatBalance = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  const formatAccountNumber = (number: string) => {
    return `****${number.slice(-4)}`;
  };

  return (
    <Card className={`bg-gradient-to-r ${gradient} text-white border-0 shadow-lg hover-elevate cursor-pointer`} data-testid={`card-account-${accountType.toLowerCase()}`}>
      <CardHeader className="flex flex-row items-start justify-between space-y-0 pb-2">
        <div className="space-y-1">
          <Badge variant="secondary" className="bg-white/20 text-white border-0 hover:bg-white/30">
            {accountType}
          </Badge>
          <h3 className="font-semibold text-lg" data-testid={`text-account-name-${accountType.toLowerCase()}`}>{accountName}</h3>
        </div>
        <Button 
          size="icon" 
          variant="ghost" 
          className="text-white hover:bg-white/20"
          data-testid={`button-account-menu-${accountType.toLowerCase()}`}
        >
          <MoreHorizontal className="h-4 w-4" />
        </Button>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="space-y-1">
            <p className="text-white/80 text-sm">Available Balance</p>
            <div className="flex items-center gap-2">
              <p className="text-2xl font-bold" data-testid={`text-balance-${accountType.toLowerCase()}`}>
                {showBalance ? formatBalance(balance) : "••••••"}
              </p>
              <Button
                size="icon"
                variant="ghost"
                className="h-6 w-6 text-white/80 hover:bg-white/20"
                onClick={() => setShowBalance(!showBalance)}
                data-testid={`button-toggle-balance-${accountType.toLowerCase()}`}
              >
                {showBalance ? <EyeOff className="h-3 w-3" /> : <Eye className="h-3 w-3" />}
              </Button>
            </div>
          </div>
        </div>
        <div className="flex justify-between items-end">
          <div>
            <p className="text-white/60 text-xs">Account Number</p>
            <p className="text-white/80 text-sm font-mono" data-testid={`text-account-number-${accountType.toLowerCase()}`}>
              {formatAccountNumber(accountNumber)}
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}