import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Send, Mic, X } from "lucide-react";
import { useState, useRef, useEffect } from "react";
import aiAvatarImage from "@assets/generated_images/AI_banking_assistant_avatar_819b322c.png";

interface ChatMessage {
  id: string;
  message: string;
  response?: string;
  timestamp: string;
  isUser: boolean;
}

interface ChatInterfaceProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function ChatInterface({ isOpen, onClose }: ChatInterfaceProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      message: '',
      response: "Hi! I'm NOA, your NextGen Online Assistant. I'm here to help you with your banking needs. How can I assist you today?",
      timestamp: new Date().toISOString(),
      isUser: false,
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = () => {
    if (!inputValue.trim()) return;

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      message: inputValue,
      timestamp: new Date().toISOString(),
      isUser: true,
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setIsTyping(true);

    // TODO: remove mock functionality - replace with actual AI API call
    setTimeout(() => {
      const aiResponse: ChatMessage = {
        id: (Date.now() + 1).toString(),
        message: '',
        response: generateMockResponse(inputValue),
        timestamp: new Date().toISOString(),
        isUser: false,
      };
      setMessages(prev => [...prev, aiResponse]);
      setIsTyping(false);
    }, 1500);
  };

  // TODO: remove mock functionality
  const generateMockResponse = (input: string): string => {
    const lowerInput = input.toLowerCase();
    
    if (lowerInput.includes('balance') || lowerInput.includes('account')) {
      return "Your Primary Checking account balance is $2,840.50. Your Emergency Savings has $12,450.00. Would you like to see more details about any specific account?";
    }
    
    if (lowerInput.includes('transaction') || lowerInput.includes('recent') || lowerInput.includes('spent')) {
      return "Your recent transactions show a $4.50 coffee purchase at Starbucks and an $89.99 Amazon purchase. This month you've spent $1,847.32 total. Would you like me to break this down by category?";
    }
    
    if (lowerInput.includes('budget') || lowerInput.includes('saving')) {
      return "You're doing great with your budget! You've spent 67% of your monthly food budget and 45% of your shopping budget. I recommend setting aside $200 more this month to reach your savings goal.";
    }
    
    if (lowerInput.includes('transfer') || lowerInput.includes('pay') || lowerInput.includes('send')) {
      return "I can help you transfer money between accounts or send payments. Which account would you like to transfer from, and where should the money go?";
    }
    
    return "I understand you're asking about your finances. I can help you check account balances, review transactions, manage budgets, transfer money, and provide personalized financial insights. What specific information would you like to know?";
  };

  const handleVoiceInput = () => {
    setIsListening(!isListening);
    // TODO: remove mock functionality - implement actual speech recognition
    console.log('Voice input toggled:', !isListening);
    
    if (!isListening) {
      // Mock voice input
      setTimeout(() => {
        setInputValue("What's my account balance?");
        setIsListening(false);
      }, 2000);
    }
  };

  const formatTime = (timestamp: string) => {
    return new Date(timestamp).toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: '2-digit',
    });
  };

  if (!isOpen) return null;

  return (
    <Card className="fixed bottom-4 right-4 w-96 h-96 z-50 flex flex-col shadow-xl" data-testid="card-chat-interface">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3 border-b">
        <div className="flex items-center gap-3">
          <Avatar className="h-8 w-8">
            <AvatarImage src={aiAvatarImage} alt="NOA Assistant" />
            <AvatarFallback>NOA</AvatarFallback>
          </Avatar>
          <div>
            <CardTitle className="text-lg" data-testid="text-assistant-name">NOA Assistant</CardTitle>
            <Badge variant="secondary" className="text-xs" data-testid="badge-assistant-status">
              Online
            </Badge>
          </div>
        </div>
        <Button 
          size="icon" 
          variant="ghost" 
          onClick={onClose}
          data-testid="button-close-chat"
        >
          <X className="h-4 w-4" />
        </Button>
      </CardHeader>
      
      <CardContent className="flex-1 overflow-y-auto space-y-4 p-4">
        {messages.map((message) => (
          <div
            key={message.id}
            className={`flex ${message.isUser ? 'justify-end' : 'justify-start'}`}
            data-testid={`message-${message.id}`}
          >
            <div className={`max-w-[75%] space-y-2 ${message.isUser ? 'order-2' : 'order-1'}`}>
              {!message.isUser && (
                <div className="flex items-center gap-2">
                  <Avatar className="h-6 w-6">
                    <AvatarImage src={aiAvatarImage} alt="NOA" />
                    <AvatarFallback>NOA</AvatarFallback>
                  </Avatar>
                  <span className="text-xs text-muted-foreground">NOA</span>
                </div>
              )}
              <div
                className={`p-3 rounded-lg ${
                  message.isUser
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-muted'
                }`}
              >
                <p className="text-sm" data-testid={`text-message-content-${message.id}`}>
                  {message.isUser ? message.message : message.response}
                </p>
              </div>
              <p className="text-xs text-muted-foreground text-right" data-testid={`text-message-time-${message.id}`}>
                {formatTime(message.timestamp)}
              </p>
            </div>
          </div>
        ))}
        
        {isTyping && (
          <div className="flex justify-start" data-testid="indicator-typing">
            <div className="flex items-center gap-2">
              <Avatar className="h-6 w-6">
                <AvatarImage src={aiAvatarImage} alt="NOA" />
                <AvatarFallback>NOA</AvatarFallback>
              </Avatar>
              <div className="bg-muted p-3 rounded-lg">
                <div className="flex space-x-1">
                  <div className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce"></div>
                  <div className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                  <div className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                </div>
              </div>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </CardContent>
      
      <div className="p-4 border-t">
        <div className="flex gap-2">
          <Input
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            placeholder="Ask NOA about your finances..."
            onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
            className="flex-1"
            data-testid="input-chat-message"
          />
          <Button
            size="icon"
            variant={isListening ? "default" : "ghost"}
            onClick={handleVoiceInput}
            className={isListening ? "animate-pulse" : ""}
            data-testid="button-voice-input"
          >
            <Mic className="h-4 w-4" />
          </Button>
          <Button 
            size="icon" 
            onClick={handleSendMessage}
            disabled={!inputValue.trim()}
            data-testid="button-send-message"
          >
            <Send className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </Card>
  );
}