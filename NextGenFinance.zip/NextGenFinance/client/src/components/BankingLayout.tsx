import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "./AppSidebar";
import { Button } from "@/components/ui/button";
import { MessageCircle } from "lucide-react";
import { useState } from "react";
import ChatInterface from "./ChatInterface";
import ThemeToggle from "./ThemeToggle";
import heroBackground from "@assets/generated_images/Banking_hero_background_62e942c4.png";

interface BankingLayoutProps {
  children: React.ReactNode;
}

export default function BankingLayout({ children }: BankingLayoutProps) {
  const [isChatOpen, setIsChatOpen] = useState(false);

  const style = {
    "--sidebar-width": "16rem",
    "--sidebar-width-icon": "4rem",
  };

  return (
    <SidebarProvider style={style as React.CSSProperties}>
      <div className="flex h-screen w-full">
        <AppSidebar />
        <div className="flex flex-col flex-1 overflow-hidden">
          <header className="flex items-center justify-between p-4 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
            <div className="flex items-center gap-4">
              <SidebarTrigger data-testid="button-sidebar-toggle" />
              <div className="hidden sm:block">
                <h1 className="text-xl font-semibold text-banking-trust" data-testid="text-app-title">
                  NOA Banking
                </h1>
                <p className="text-sm text-muted-foreground">NextGen Online Assistant</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <ThemeToggle />
              <Button
                variant="default"
                size="sm"
                onClick={() => setIsChatOpen(true)}
                className="gap-2"
                data-testid="button-open-chat"
              >
                <MessageCircle className="h-4 w-4" />
                <span className="hidden sm:inline">Chat with NOA</span>
              </Button>
            </div>
          </header>
          
          <main className="flex-1 overflow-y-auto bg-background">
            {/* Hero Section */}
            <div 
              className="relative bg-gradient-to-r from-banking-trust to-blue-800 text-white py-12 px-6"
              style={{
                backgroundImage: `linear-gradient(rgba(37, 99, 235, 0.8), rgba(29, 78, 216, 0.9)), url(${heroBackground})`,
                backgroundSize: 'cover',
                backgroundPosition: 'center',
              }}
            >
              <div className="max-w-4xl mx-auto">
                <h2 className="text-3xl md:text-4xl font-bold mb-4" data-testid="text-hero-title">
                  Welcome to the Future of Banking
                </h2>
                <p className="text-lg text-white/90 mb-6" data-testid="text-hero-subtitle">
                  Experience intelligent financial management with NOA, your AI-powered assistant
                </p>
                <div className="flex flex-wrap gap-4">
                  <Button 
                    variant="outline" 
                    size="lg" 
                    className="bg-white/10 border-white/20 text-white hover:bg-white/20 backdrop-blur"
                    data-testid="button-hero-chat"
                    onClick={() => setIsChatOpen(true)}
                  >
                    Ask NOA Anything
                  </Button>
                  <Button 
                    variant="outline" 
                    size="lg" 
                    className="bg-white/10 border-white/20 text-white hover:bg-white/20 backdrop-blur"
                    data-testid="button-hero-explore"
                  >
                    Explore Features
                  </Button>
                </div>
              </div>
            </div>
            
            {/* Main Content */}
            <div className="p-6">
              {children}
            </div>
          </main>
        </div>
      </div>
      
      <ChatInterface isOpen={isChatOpen} onClose={() => setIsChatOpen(false)} />
    </SidebarProvider>
  );
}