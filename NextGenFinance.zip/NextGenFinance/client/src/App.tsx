import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import BankingLayout from "@/components/BankingLayout";
import Dashboard from "@/pages/Dashboard";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/accounts" component={() => <div className="p-8 text-center text-muted-foreground">Accounts page coming soon...</div>} />
      <Route path="/analytics" component={() => <div className="p-8 text-center text-muted-foreground">Analytics page coming soon...</div>} />
      <Route path="/budgets" component={() => <div className="p-8 text-center text-muted-foreground">Budgets page coming soon...</div>} />
      <Route path="/bills" component={() => <div className="p-8 text-center text-muted-foreground">Bills & Payments page coming soon...</div>} />
      <Route path="/assistant" component={() => <div className="p-8 text-center text-muted-foreground">AI Assistant page coming soon...</div>} />
      <Route path="/insights" component={() => <div className="p-8 text-center text-muted-foreground">Financial Insights page coming soon...</div>} />
      <Route path="/security" component={() => <div className="p-8 text-center text-muted-foreground">Security page coming soon...</div>} />
      <Route path="/settings" component={() => <div className="p-8 text-center text-muted-foreground">Settings page coming soon...</div>} />
      <Route component={NotFound} />
    </Switch>
  );
}

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <BankingLayout>
          <Router />
        </BankingLayout>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}