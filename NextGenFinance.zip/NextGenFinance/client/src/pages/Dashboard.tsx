import AccountCard from "@/components/AccountCard";
import DashboardOverview from "@/components/DashboardOverview";
import TransactionList from "@/components/TransactionList";
import QuickActions from "@/components/QuickActions";

export default function Dashboard() {
  // TODO: remove mock functionality
  const mockAccounts = [
    {
      accountName: "Primary Checking",
      accountType: "Checking",
      balance: 2840.50,
      accountNumber: "1234567890",
      gradient: "from-blue-600 to-blue-800"
    },
    {
      accountName: "Emergency Savings",
      accountType: "Savings", 
      balance: 12450.00,
      accountNumber: "0987654321",
      gradient: "from-green-600 to-green-800"
    },
    {
      accountName: "Platinum Card",
      accountType: "Credit",
      balance: -892.33,
      accountNumber: "5555444433332222",
      gradient: "from-purple-600 to-purple-800"
    }
  ];

  const mockTransactions = [
    {
      id: '1',
      amount: 4.50,
      description: 'Morning Coffee',
      category: 'Food & Dining',
      type: 'debit' as const,
      date: '2024-01-15',
      merchant: 'Starbucks'
    },
    {
      id: '2',
      amount: 2500.00,
      description: 'Salary Deposit',
      category: 'Income',
      type: 'credit' as const,
      date: '2024-01-15'
    },
    {
      id: '3',
      amount: 89.99,
      description: 'Online Shopping',
      category: 'Shopping',
      type: 'debit' as const,
      date: '2024-01-14',
      merchant: 'Amazon'
    },
    {
      id: '4',
      amount: 25.00,
      description: 'Gas Station',
      category: 'Transportation',
      type: 'debit' as const,
      date: '2024-01-13',
      merchant: 'Shell'
    }
  ];

  const mockOverviewData = {
    totalBalance: 15290.50,
    monthlyIncome: 4200.00,
    monthlyExpenses: 3147.32,
    savingsGoal: 10000.00,
    currentSavings: 6750.00,
    budgetData: [
      { category: 'Food & Dining', spent: 487.23, limit: 600 },
      { category: 'Transportation', spent: 234.56, limit: 300 },
      { category: 'Shopping', spent: 892.10, limit: 800 },
      { category: 'Entertainment', spent: 156.78, limit: 200 }
    ]
  };

  const handleQuickAction = (action: string) => {
    console.log(`Quick action: ${action}`); // TODO: remove mock functionality
  };

  return (
    <div className="space-y-8" data-testid="page-dashboard">
      {/* Account Cards */}
      <section>
        <h2 className="text-2xl font-semibold mb-6" data-testid="text-accounts-heading">Your Accounts</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {mockAccounts.map((account, index) => (
            <AccountCard key={index} {...account} />
          ))}
        </div>
      </section>

      {/* Quick Actions */}
      <QuickActions onActionClick={handleQuickAction} />

      {/* Dashboard Overview */}
      <DashboardOverview {...mockOverviewData} />

      {/* Recent Transactions */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <TransactionList transactions={mockTransactions} />
        
        {/* AI Insights Card */}
        <div className="bg-gradient-to-br from-banking-trust/10 to-blue-100 dark:from-banking-trust/5 dark:to-blue-950/20 rounded-lg p-6 border">
          <h3 className="text-lg font-semibold mb-4 text-banking-trust" data-testid="text-ai-insights-title">
            AI Insights from NOA
          </h3>
          <div className="space-y-3">
            <div className="p-3 bg-background rounded-lg">
              <p className="text-sm text-muted-foreground mb-1">Spending Pattern</p>
              <p className="text-sm" data-testid="text-spending-insight">
                You're spending 23% more on food this month. Consider meal planning to save $127.
              </p>
            </div>
            <div className="p-3 bg-background rounded-lg">
              <p className="text-sm text-muted-foreground mb-1">Savings Opportunity</p>
              <p className="text-sm" data-testid="text-savings-insight">
                Based on your income, you could save an additional $300/month by optimizing subscriptions.
              </p>
            </div>
            <div className="p-3 bg-background rounded-lg">
              <p className="text-sm text-muted-foreground mb-1">Goal Progress</p>
              <p className="text-sm" data-testid="text-goal-insight">
                You're on track to reach your emergency fund goal 2 months early! Great work!
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}